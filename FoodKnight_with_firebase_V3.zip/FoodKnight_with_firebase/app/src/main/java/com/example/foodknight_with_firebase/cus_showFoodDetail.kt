package com.example.foodknight_with_firebase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.example.foodknight_with_firebase.databinding.ActivityCusShowFoodDetailBinding
import com.example.foodknight_with_firebase.databinding.ActivityResShowFoodBinding
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.awaitAll
import android.view.View;


private  lateinit var binding: ActivityCusShowFoodDetailBinding

private lateinit var db : FirebaseFirestore

class cus_showFoodDetail : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCusShowFoodDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var minus = binding.less
        var add = binding.more
        ///var qtyNum = binding.prnumber.text.toString().toInt()
        var qty = binding.prnumber

        val food = intent.getParcelableExtra<cusFoodList>("foodInfo")
        db = FirebaseFirestore.getInstance()
        if (food != null) {
            var resEmail = food.uid
            var foodName = food.foodName

//            var resEmail = "satishs@gmail.com"
//            var foodName = "MCBurger"

            if (resEmail != null) {
                if (foodName != null) {
                    db.collection("seller").document(resEmail).collection("foodList")
                        .document(foodName).get().addOnSuccessListener {
                            if(it!=null){
                                //foodImg.setImageResource()
                                binding.cusFdFoodName.text = it.get("foodName").toString()
                                binding.cusFdFoodDesc.text = it.get("foodDesc").toString()
                                binding.cusFdFoodPrice.text = "RM " + it.get("foodPrice").toString()
                            }
                            else{Toast.makeText(this, "Something went wrong,please try again2", Toast.LENGTH_SHORT).show()
                        }

                        }
                } else {
                    Toast.makeText(
                        this,
                        "Something went wrong,please try again3",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            } else {
                Toast.makeText(this, "Something went wrong,please try again4", Toast.LENGTH_SHORT)
                    .show()
            }
            binding.addCartBtn.setOnClickListener{
                var qtyNum = qty.text.toString().toInt()
                if(qtyNum>=1){
                    var logginedUser = "kewei2001@hotmail.com"
                   db.collection("cart").document(logginedUser).get().addOnSuccessListener{
                       if(it!=null){
                           var cartRes = it.get("restaurantEmail")
                           if(cartRes!=resEmail.toString()&&cartRes!=null){
                               Toast.makeText(this, "You can only add item from one shop", Toast.LENGTH_SHORT).show()
                           }else{
                               if(it.get("foodName")==foodName.toString()){
                                   var cartQty = qtyNum+(it.get("qty").toString().toInt())
                                   val cart:MutableMap<String,Any> = java.util.HashMap()
                                   cart["restaurantEmail"] = resEmail.toString()
                                   cart["foodName"] = foodName.toString()
                                   cart["qty"] = cartQty.toString()
                                   db.collection("cart").document(logginedUser).collection("item").document(foodName.toString()).set(cart)
                                   Toast.makeText(this, "Cart added successfully", Toast.LENGTH_SHORT).show()
                               }else{
                                   Toast.makeText(this, "You can only buy one item", Toast.LENGTH_SHORT).show()
                               }



                           }
                       }else{
                           Toast.makeText(this, "Something went wrong,pls try again", Toast.LENGTH_SHORT).show()
                       }
                   }

                }
        }



        binding.minus.setOnClickListener{
            var qtyNum = qty.text.toString().toInt()
            if(qtyNum>=1){
                qty.setText((qtyNum-1).toString())

            }
        }

        binding.add.setOnClickListener{
            var qtyNum = qty.text.toString().toInt()
            qty.setText((qtyNum+1).toString())

        }


        }
    }
}