package com.example.foodknight_with_firebase

data class history(var foodName:String?=null,var restaurantEmail:String?=null)
