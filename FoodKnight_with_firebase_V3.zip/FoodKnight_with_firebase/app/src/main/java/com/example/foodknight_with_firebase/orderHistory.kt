package com.example.foodknight_with_firebase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.foodknight_with_firebase.orderHisAdapter
import com.example.foodknight_with_firebase.showFoodAdapter
import com.example.foodknight_with_firebase.databinding.ActivityOrderHistoryBinding
import com.example.foodknight_with_firebase.databinding.ActivityResShowFoodBinding
import com.google.firebase.firestore.*

private  lateinit var binding: ActivityOrderHistoryBinding

private lateinit var db : FirebaseFirestore
private lateinit var hisRV : RecyclerView
private lateinit var hisArrayList :ArrayList<history>
private lateinit var hisAdapter2: orderHisAdapter

class orderHistory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        hisRV = binding.cusOrderHis
                hisRV.layoutManager = LinearLayoutManager(this)
        hisRV.setHasFixedSize(true)

        hisArrayList = arrayListOf()
        hisAdapter2 = orderHisAdapter(hisArrayList)
        hisRV.adapter= hisAdapter2

        getHisData()
    }

    private fun getHisData() {
        db = FirebaseFirestore.getInstance()

        var loginnedUser = "kewei2001@hotmail.com"
            db.collection("history").document(loginnedUser).collection("history")
                .addSnapshotListener(object : EventListener<QuerySnapshot> {
                override fun onEvent(value: QuerySnapshot?, error: FirebaseFirestoreException?) {
                    if (error != null) {
                        Log.e("firestore Error", error.message.toString())
                        return
                    }

                    for (dc: DocumentChange in value?.documentChanges!!) {
                        if (dc.type == DocumentChange.Type.ADDED) {
                            var item:history = dc.document.toObject(history::class.java)
                            hisArrayList.add(item)
                        }
                    }
                    hisAdapter2.notifyDataSetChanged()
                }

            })

    }


}