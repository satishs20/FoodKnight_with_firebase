package com.example.foodknight_with_firebase

class foodDetail(var foodName:String?=null,var foodDesc:String?=null,var foodLink:String?=null,var foodPrice:String?=null) {
}