package com.example.foodknight_with_firebase.ui.editDel

import androidx.lifecycle.ViewModel

class EditDelViewModel : ViewModel() {
    // TODO: Implement the ViewModel

}