package com.example.foodknight_with_firebase

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.foodknight_with_firebase.R
import com.example.foodknight_with_firebase.history
import com.example.foodknight_with_firebase.restaurant


class orderHisAdapter(private val ohList: ArrayList<history>) :
    RecyclerView.Adapter<orderHisAdapter.MyViewHolder>() {

    //var onItemClick:((restaurant)->Unit)?=null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.activity_order_history, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val currentItem: history = ohList[position]

        holder.name.text = currentItem.foodName
        holder.information.text = "From : " +currentItem.restaurantEmail

//        holder.itemView.setOnClickListener{
//            onItemClick?.invoke(currentItem)
//        }
    }

    override fun getItemCount(): Int {
        return ohList.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var name: TextView = itemView.findViewById(R.id.his_foodName)
        var information: TextView = itemView.findViewById(R.id.his_res)
    }


}