package com.example.foodknight_with_firebase.ui

import android.view.View
import android.widget.ImageView

data class Foods(var foodDesc: String ?= null,var foodName: String ?= null, var foodPrice: String ?= null, var foodLink: String ?= null
                )

