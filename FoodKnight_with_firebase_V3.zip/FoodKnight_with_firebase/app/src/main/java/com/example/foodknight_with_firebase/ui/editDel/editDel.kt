package com.example.foodknight_with_firebase.ui.editDel
import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.net.Uri
import android.os.Build
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.activityViewModels
import com.example.foodknight_with_firebase.databinding.EditDelFragmentBinding
import com.example.foodknight_with_firebase.ui.allFood.AllFoodViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso
import java.util.*

class editDel : Fragment() {
    lateinit var binding: EditDelFragmentBinding
     lateinit var remoteUrl: String
     lateinit var imageURI: Uri
    private val AllFoodViewModel : AllFoodViewModel by activityViewModels()
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel =
            ViewModelProvider(this).get(EditDelViewModel::class.java)

        binding = EditDelFragmentBinding.inflate(inflater, container, false)
        val root: View = binding.root


       // val foodName : TextView = binding.txtFoodName
       // val foodDesc : TextView = binding.txtDesc
       // val foodPrice : TextView = binding.txtPrice
        //val args = this.arguments
       // val foodLink = args?.get("foodLink").toString()
       // Picasso.get().load(foodLink).into(binding.foodPic)
        //val oo : TextView=  binding.txtFoodName
        AllFoodViewModel.foodLink.observe(viewLifecycleOwner) { foodLink ->Picasso.get().load(foodLink).into(binding.foodPic) }
        AllFoodViewModel.foodName.observe(viewLifecycleOwner) { foodName -> binding.txtFoodName.setText(foodName) }
        AllFoodViewModel.foodDesc.observe(viewLifecycleOwner) { foodDesc -> binding.txtDesc.setText(foodDesc) }
        AllFoodViewModel.foodPrice.observe(viewLifecycleOwner) { foodPrice -> binding.txtPrice.setText(foodPrice) }

        val id = binding.txtFoodName.toString()

        binding.btnAdd.setOnClickListener {
            selectImage()
        }

        binding.btnUpload.setOnClickListener{

            uploadImage(id)
        }

        binding.btnDelete.setOnClickListener{

            delete()
        }

       // foodDesc.text =  args?.get("foodDesc").toString()
        //foodPrice.text =  args?.get("foodPrice").toString()
       return root
    }
    lateinit var aa :ProgressDialog
    @RequiresApi(Build.VERSION_CODES.N)

    private fun uploadImage(id: String) {
        val progressDialog =  ProgressDialog(activity);
        progressDialog.setMessage("Uploading file..")
        progressDialog.setCancelable(false)
        progressDialog.show()

        val formatter = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault())
        val imageIdentifier = UUID.randomUUID().toString() + ".png";
        val now = Date()
        val fileName = formatter.format(now)
        val storageReference = FirebaseStorage.getInstance().getReference("images\$fileName").child(imageIdentifier)


        val uploadTask = storageReference.putFile(imageURI).

        addOnSuccessListener {

            binding.foodPic.setImageURI(imageURI)
            val downloadUrl = storageReference.downloadUrl

            downloadUrl.addOnSuccessListener {
                var remoteUrl = it.toString()
                // update our Cloud Firestore with the public image URI.
                saveData(remoteUrl,id)
            }
            Toast.makeText(activity, "Succesfuly Uploaded", Toast.LENGTH_SHORT).show()

            progressDialog.dismiss()
        }.
        addOnFailureListener {
            progressDialog.dismiss()

            Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show()

        }




    }

    private fun delete(){
        val foodName = binding.txtFoodName.text.toString()
        val foodPrice = binding.txtPrice.text.toString()
        val foodDesc = binding.txtDesc.text.toString()
        val db = FirebaseFirestore.getInstance()

        val progressDialog =  ProgressDialog(activity);
        progressDialog.setMessage("Uploading file..")
        progressDialog.setCancelable(false)
        progressDialog.show()
        val email = "satishs@gmail.com"

        db.collection("seller").document(email).collection("foodList").document(foodName).delete()

            .
            addOnSuccessListener {
                Toast.makeText(activity, "Successfully Uploaded", Toast.LENGTH_SHORT).show()
                progressDialog.dismiss()
            }.
            addOnFailureListener {
                Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show()
                progressDialog.dismiss()

            }
    }


    private fun saveData(remoteUrl: String, id: String,) {
        val foodName = binding.txtFoodName.text.toString()
        val foodPrice = binding.txtPrice.text.toString()
        val foodDesc = binding.txtDesc.text.toString()
        val db = FirebaseFirestore.getInstance()

        val progressDialog =  ProgressDialog(activity);
        progressDialog.setMessage("Uploading file..")
        progressDialog.setCancelable(false)
        progressDialog.show()
        val email = "satishs@gmail.com"
        val food: MutableMap<String, Any> = java.util.HashMap()
        food["foodDesc"] = foodDesc
        food["foodLink"] = remoteUrl
        food["foodName"] = foodName
        food["foodPrice"] = foodPrice




        db.collection("seller").document(email).collection("foodList").document(foodName).set(food)
            .
            addOnSuccessListener {
                Toast.makeText(activity, "Successfully Uploaded", Toast.LENGTH_SHORT).show()
                progressDialog.dismiss()
            }.
            addOnFailureListener {
                Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show()
                progressDialog.dismiss()

            }

    }




    private fun selectImage() {
        val intent = Intent();
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT

        startActivityForResult(intent,100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 100 && resultCode == Activity.RESULT_OK)

            imageURI = data?.data!!
        binding.foodPic.setImageURI(imageURI)

    }
}