package com.example.foodknight_with_firebase.ui.addFood

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.foodknight_with_firebase.databinding.FragmentAddFoodBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import java.util.*

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
private lateinit var  db:FirebaseFirestore

/**
 * A simple [Fragment] subclass.
 * Use the [addFood.newInstance] factory method to
 * create an instance of this fragment.
 */
class addFood : Fragment() {
    // TODO: Rename and change types of parameters

    lateinit var binding: FragmentAddFoodBinding
    lateinit var imageURI: Uri
    private   lateinit var remoteUrl: String
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val galleryViewModel =
            ViewModelProvider(this).get(AddFoodViewModel::class.java)

        binding = FragmentAddFoodBinding.inflate(inflater, container, false)
        val root: View = binding.root


        binding.btnAdd.setOnClickListener {
            selectImage()
        }

        binding.btnUpload.setOnClickListener {


             uploadImage()

        }

        return root
    }
    lateinit var aa :ProgressDialog
    @RequiresApi(Build.VERSION_CODES.N)

    private fun uploadImage() {
        val progressDialog =  ProgressDialog(activity);
        progressDialog.setMessage("Uploading file..")
        progressDialog.setCancelable(false)
        progressDialog.show()

        val formatter = SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.getDefault())
        val imageIdentifier = UUID.randomUUID().toString() + ".png";
        val now = Date()
        val fileName = formatter.format(now)
        val storageReference = FirebaseStorage.getInstance().getReference("images\$fileName").child(imageIdentifier)


        val uploadTask = storageReference.putFile(imageURI).

        addOnSuccessListener {

            binding.foodPic.setImageURI(imageURI)
            val downloadUrl = storageReference.downloadUrl

            downloadUrl.addOnSuccessListener {
                var remoteUrl = it.toString()
                // update our Cloud Firestore with the public image URI.
                 saveData(remoteUrl)
            }
            Toast.makeText(activity, "Succesfuly Uploaded", Toast.LENGTH_SHORT).show()

                progressDialog.dismiss()
        }.
        addOnFailureListener {
           progressDialog.dismiss()

            Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show()

        }




    }

    private fun saveData(remoteUrl: String) {
        val foodName = binding.txtFoodName.text.toString()
        val foodPrice = binding.txtPrice.text.toString()
        val foodDesc = binding.txtDesc.text.toString()
        val db = FirebaseFirestore.getInstance()

        val progressDialog =  ProgressDialog(activity);
        progressDialog.setMessage("Uploading file..")
        progressDialog.setCancelable(false)
        progressDialog.show()
        val loginnedUser = Firebase.auth.currentUser
        val email = loginnedUser?.email
        val food: MutableMap<String, Any> = java.util.HashMap()
        food["foodDesc"] = foodDesc
        food["foodLink"] = remoteUrl
        food["foodName"] = foodName
        food["foodPrice"] = foodPrice




        if (email != null) {
            db.collection("seller").document(email).collection("foodList").document(foodName).set(food)
                .
                addOnSuccessListener {
                    Toast.makeText(activity, "Successfully Uploaded", Toast.LENGTH_SHORT).show()
                    progressDialog.dismiss()
                }.
                addOnFailureListener {
                    Toast.makeText(activity, "Failed", Toast.LENGTH_SHORT).show()
                    progressDialog.dismiss()

                }
        }

    }




    private fun selectImage() {
        val intent = Intent();
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT

        startActivityForResult(intent,100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 100 && resultCode == Activity.RESULT_OK)

            imageURI = data?.data!!
        binding.foodPic.setImageURI(imageURI)

    }
}